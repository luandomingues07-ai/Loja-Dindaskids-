
let carrinho = [];

function adicionarAoCarrinho(produto, preco) {
  carrinho.push({ nome: produto, preco: preco });
  document.getElementById('quantidade').innerText = carrinho.length;
  alert(produto + ' foi adicionado ao carrinho!');
}

function verCarrinho() {
  if (carrinho.length === 0) {
    alert('Seu carrinho está vazio!');
    return;
  }
  let total = 0;
  const lista = carrinho.map(item => {
    total += item.preco;
    return `- ${item.nome} (R$ ${item.preco.toFixed(2)})`;
  }).join('\n');
  const msg = `Olá, gostaria de comprar:\n${lista}\n\nTotal: R$ ${total.toFixed(2)}\n\nAceitam Pix ou posso pagar com PagSeguro?`;
  const url = `https://wa.me/5591999990000?text=${encodeURIComponent(msg)}`;
  window.open(url, '_blank');
}
